/* global angular */

(function(){
    angular.module('googlechart.mocks', []);
})();
